package kundapanda.autisti.tiqr

class Server {
}